# MedShop-RAG — ISIR-eCom 2026 Submission Package

**Paper:** MedShop-RAG: Safety-Aware Retrieval-Augmented Product Search for OTC Healthcare E-Commerce  
**Venue:** ISIR-eCom 2026 — 2nd Workshop on Information Search and Retrieval for E-Commerce  
**Co-located with:** IEEE International Conference on Big Data (IEEE BigData 2026), Washington D.C., December 2026  
**Submission date:** October 30, 2026  
**Format:** IEEE 2-column conference, full paper (≤ 10 pages)

---

## Package Contents

```
MedShopRAG_ISIReCom2026_Submission/
├── README_SUBMISSION.md              ← this file
├── MedShopRAG_CoverLetter_ISIReCom2026.docx  ← camera-ready cover letter
├── RESULT_MANIFEST.json              ← master results manifest (all locked values)
└── latex/
    ├── medshop_rag_ieee.tex          ← IEEE LaTeX source (single file, self-contained)
    ├── medshop_rag_ieee.pdf          ← compiled PDF (6 pages, 0 errors)
    ├── Makefile                      ← build script (pdflatex ×2 for cross-refs)
    └── README.md                     ← build instructions + pre-submission checklist
```

---

## Key Locked Results (from RESULT_MANIFEST.json)

| Metric | Value |
|---|---|
| NDCG@10 (MedShop-RAG) | 0.7514 |
| Safety Sensitivity | 0.3469 |
| Safety Precision | 0.9444 |
| Safety F1 | 0.5075 |
| McNemar χ² | 12.5 (p = 0.0004) |
| Citation Accuracy (SCI-CHECK) | 1.0 (κ = 1.0) |
| H1 NDCG@10 improvement | NOT_SUPPORTED |
| H2 Sensitivity ≥ 0.80 | NOT_SUPPORTED |
| H3 Citation accuracy ≥ 80% | SUPPORTED |

> **Note:** All experiments were conducted on SYNTHETIC_DATA (60 products, 100 queries, 100 safety pairs).
> A Phase 2 real-data validation roadmap (ShoppingComp + DrugBench) is described in Section VI-C of the manuscript.

---

## Build Instructions

To recompile the PDF from source:

```bash
cd latex/
make          # runs pdflatex twice; output: medshop_rag_ieee.pdf
```

Requires: `pdflatex`, `IEEEtran.cls` (included in most TeX distributions), `tikz`, `booktabs`, `hyperref`.

---

## Author Placeholders

Three contact placeholders remain in the cover letter (`[To be Added]`):
- Corresponding author name
- Affiliation
- Email address

Fill these before final submission.
